var express = require('express');
var bodyParser = require('body-parser');
var path = require('path');
const app = express();
var port = 2121;


app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

const ilceler = require('./ilceler.json');


app.get('/', (req, res) => {
    res.render('index', { ilceler: ilceler });
});


app.post("/ara", (req, res) => {
    const aranacakTerim = req.body.aranacakTerim.toLowerCase();

    const sonuc = ilceler.filter(ilce => {
        const sehirIdMatch = String(ilce.sehir_id).toLowerCase().includes(aranacakTerim);
        const ilceAdiMatch = String(ilce.ilce_adi).toLowerCase().includes(aranacakTerim);
        return sehirIdMatch || ilceAdiMatch;
    });

    res.render('index', { ilceler: sonuc });
});


app.get('/iletisim', (req, res) => 
{
    res.render('iletisim');
});




app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});










